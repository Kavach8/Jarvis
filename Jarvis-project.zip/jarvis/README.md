# Jarvis – Android voice/text assistant

## Get the APK (no Android Studio needed)
1. Create a free GitHub account and a new repository (e.g. `jarvis`).
2. Upload everything in this folder (keep the `.github` folder) and commit.
3. Open the **Actions** tab → **Build Jarvis APK** → wait ~5 minutes for the green tick.
4. Open that run → **Artifacts** → download **Jarvis-APK** → unzip → `app-debug.apk`.
5. Copy the APK to your phone, tap it, allow "Install unknown apps".

(Or open this folder in Android Studio and press Build > Build APK.)

## First-time setup on the phone
1. Open Jarvis → **Grant permissions** → allow all.
2. **Enable control** → Installed apps → Jarvis → turn on (needed for scroll, tap, type,
   searching inside apps, pressing Send in WhatsApp/Instagram).
   On Android 13+ if it is greyed out: App info → ⋮ → "Allow restricted settings".
3. Use the mic button or type commands. Say "help" for the list.

## Commands
- set alarm at 6:30 am · set timer for 10 minutes
- call Mom · call 9876543210
- open YouTube · open Chrome and search cats
- search lofi on youtube · search pizza on maps · search shoes on Amazon
- send sms to Mom saying I'm on my way
- whatsapp to Rahul saying hello · instagram to john_doe saying hey
- scroll down · scroll up 3 times · type hello world · tap Search · go back · go home
- take a photo · take a selfie · record a video for 20 seconds · stop recording

## Notes
- Contact names need the Contacts permission; otherwise say the number. 10-digit numbers
  default to country code +91 for WhatsApp (change `DEFAULT_COUNTRY_CODE` in `JarvisEngine.kt`).
- Instagram/WhatsApp sending works by driving their screens, so it can break if the apps change.
- Commands are matched by patterns, not an AI model, so phrase them like the examples.
- Jarvis only listens when you press the mic button (no always-on "Hey Jarvis").
- Photos go to Pictures/Jarvis, videos to Movies/Jarvis.
