package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import java.util.Locale

/**
 * Always-listening "Hey Jarvis" service.
 * Say "Jarvis <command>" in one go, or say "Jarvis", wait for "Yes?", then say the command.
 */
class WakeService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var running = false

        /** Set by MainActivity while it is on screen so heard commands and replies show in the chat. */
        @Volatile
        var onMessage: ((String, Boolean) -> Unit)? = null

        private const val CHANNEL = "jarvis_wake"
        private val WAKE_WORDS = listOf("jarvis", "jarvas", "jarwis", "jervis", "harvis")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var awaiting = false
    private var awaitingUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    handler.postDelayed({ resumeAfterSpeech() }, 400)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.postDelayed({ resumeAfterSpeech() }, 400)
                }
            })
            ttsReady = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Hey Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" followed by a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        try {
            ServiceCompat.startForeground(
                this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } catch (e: Exception) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onMessage?.invoke("Speech recognition isn't available on this phone.", false)
            stopSelf()
            return START_NOT_STICKY
        }
        handler.post { listen() }
        return START_STICKY
    }

    // ------------------------------------------------------------------ listening loop

    private fun listen() {
        if (!running || speaking) return
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(listener)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            r.startListening(i)
        } catch (e: Exception) {
            handler.postDelayed({ listen() }, 2000)
        }
    }

    private fun resumeAfterSpeech() {
        speaking = false
        listen()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                onMessage?.invoke("Microphone permission is missing, so Hey Jarvis stopped.", false)
                stopSelf()
                return
            }
            val delay = when (error) {
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> 1500L
                else -> 400L
            }
            handler.postDelayed({ listen() }, delay)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (list != null) process(list)
            if (!speaking) handler.postDelayed({ listen() }, 300)
        }
    }

    // ------------------------------------------------------------------ wake word + command

    private fun process(heard: List<String>) {
        val now = SystemClock.elapsedRealtime()

        for (s in heard) {
            val lower = s.lowercase()
            val word = WAKE_WORDS.firstOrNull { it in lower } ?: continue
            val idx = lower.indexOf(word)
            val cmd = s.substring(idx + word.length).trim().trimStart(',', '.', ' ')
            if (cmd.isEmpty()) {
                awaiting = true
                awaitingUntil = now + 8000
                say("Yes?")
            } else {
                awaiting = false
                dispatch(cmd)
            }
            return
        }

        if (awaiting && now < awaitingUntil && heard.isNotEmpty()) {
            awaiting = false
            dispatch(heard.first())
        }
    }

    private fun dispatch(cmd: String) {
        onMessage?.invoke(cmd, true)
        JarvisEngine.run(applicationContext, cmd) { reply ->
            onMessage?.invoke(reply, false)
            say(reply.lines().first())
        }
    }

    private fun say(text: String) {
        if (!ttsReady) {
            handler.postDelayed({ listen() }, 500)
            return
        }
        speaking = true
        recognizer?.destroy()
        recognizer = null
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wake_" + SystemClock.elapsedRealtime())
        // Safety net in case the speech callback never arrives.
        handler.postDelayed({ if (speaking) resumeAfterSpeech() }, 9000)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        super.onDestroy()
    }
}
