package com.jarvis.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date

data class AiConfig(val provider: String, val key: String, val model: String)

/**
 * Optional AI "brain". When Jarvis's built-in patterns don't understand a sentence,
 * the sentence is sent to the AI service the user chose (Gemini, Claude or OpenAI).
 * The AI answers with JSON: either a command Jarvis already knows, or a chat reply.
 * The API key is typed into the app and stored only on this phone.
 */
object AiBrain {

    val PROVIDERS = listOf("Gemini", "Claude", "OpenAI")

    class AiResult(val command: String, val reply: String)

    fun defaultModel(provider: String): String = when (provider) {
        "Claude" -> "claude-haiku-5-5"
        "OpenAI" -> "gpt-4o-mini"
        else -> "gemini-2.5-flash"
    }

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("jarvis_ai", Context.MODE_PRIVATE)

    fun load(ctx: Context): AiConfig {
        val p = prefs(ctx)
        return AiConfig(
            p.getString("provider", PROVIDERS[0]) ?: PROVIDERS[0],
            p.getString("key", "") ?: "",
            p.getString("model", "") ?: ""
        )
    }

    fun save(ctx: Context, c: AiConfig) {
        prefs(ctx).edit()
            .putString("provider", c.provider)
            .putString("key", c.key)
            .putString("model", c.model)
            .apply()
    }

    fun enabled(ctx: Context): Boolean = load(ctx).key.isNotBlank()

    private fun systemPrompt(): String = """
        You are Jarvis, a voice assistant inside an Android phone app. Today is ${Date()}.
        The user speaks or types a request. Reply with ONLY a JSON object, no markdown:
        {"command": "<one command or empty string>", "reply": "<short reply>"}

        If the user wants the phone to DO something, set "command" to exactly ONE command in one of
        these formats (keep names, numbers and message text exactly as the user said them):
        - set alarm at 6:30 am
        - set timer for 10 minutes   (units: seconds, minutes, hours)
        - call NAME_OR_NUMBER
        - open APP_NAME
        - search QUERY on APP_NAME   (for a normal web search use: search QUERY)
        - sms to NAME_OR_NUMBER saying MESSAGE
        - whatsapp to NAME_OR_NUMBER saying MESSAGE
        - instagram to USERNAME saying MESSAGE
        - scroll down   (or up, left, right; may add "3 times")
        - type TEXT
        - tap BUTTON_LABEL
        - go back
        - go home
        - take a photo
        - take a selfie
        - record a video for 20 seconds
        - stop recording
        Convert times like "wake me up at half past six" into "set alarm at 6:30 am" and "in 20 minutes"
        into "set timer for 20 minutes". Put a very short confirmation in "reply".

        If the user just asks a question or chats, set "command" to "" and answer in "reply" in at most
        two short sentences, in the language the user used.
    """.trimIndent()

    suspend fun ask(ctx: Context, userText: String): AiResult = withContext(Dispatchers.IO) {
        val cfg = load(ctx)
        val model = cfg.model.ifBlank { defaultModel(cfg.provider) }
        val sys = systemPrompt()

        val raw: String = when (cfg.provider) {
            "Claude" -> {
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", 400)
                    .put("system", sys)
                    .put(
                        "messages",
                        JSONArray().put(JSONObject().put("role", "user").put("content", userText))
                    )
                val res = post(
                    "https://api.anthropic.com/v1/messages",
                    mapOf(
                        "x-api-key" to cfg.key,
                        "anthropic-version" to "2023-06-01",
                        "content-type" to "application/json"
                    ),
                    body.toString()
                )
                JSONObject(res).getJSONArray("content").getJSONObject(0).getString("text")
            }

            "OpenAI" -> {
                val body = JSONObject()
                    .put("model", model)
                    .put(
                        "messages",
                        JSONArray()
                            .put(JSONObject().put("role", "system").put("content", sys))
                            .put(JSONObject().put("role", "user").put("content", userText))
                    )
                    .put("response_format", JSONObject().put("type", "json_object"))
                val res = post(
                    "https://api.openai.com/v1/chat/completions",
                    mapOf(
                        "Authorization" to "Bearer ${cfg.key}",
                        "Content-Type" to "application/json"
                    ),
                    body.toString()
                )
                JSONObject(res).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
            }

            else -> {
                val body = JSONObject()
                    .put(
                        "systemInstruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))
                    )
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put("role", "user")
                                .put("parts", JSONArray().put(JSONObject().put("text", userText)))
                        )
                    )
                    .put(
                        "generationConfig",
                        JSONObject().put("responseMimeType", "application/json")
                    )
                val res = post(
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                    mapOf(
                        "x-goog-api-key" to cfg.key,
                        "Content-Type" to "application/json"
                    ),
                    body.toString()
                )
                JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                    .getString("text")
            }
        }
        parse(raw)
    }

    private fun parse(raw: String): AiResult {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return AiResult("", raw.trim())
        return try {
            val o = JSONObject(raw.substring(start, end + 1))
            AiResult(o.optString("command", "").trim(), o.optString("reply", "").trim())
        } catch (e: Exception) {
            AiResult("", raw.trim())
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.doOutput = true
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code ${text.take(160)}")
        return text
    }
}
