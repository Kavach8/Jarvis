package com.jarvis.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Turns a typed or spoken sentence into an action.
 * Parsing is rule-based (regex), so it works offline and needs no API key.
 */
object JarvisEngine {

    /** Used when a phone number is typed without a country code (WhatsApp needs one). */
    private const val DEFAULT_COUNTRY_CODE = "91"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val HELP = """
        Try saying:
        • set alarm at 6:30 am
        • set timer for 10 minutes
        • call Mom   /   call 9876543210
        • open YouTube
        • search lofi music on youtube
        • send sms to Mom saying I'm on my way
        • whatsapp to Rahul saying hello
        • instagram to john_doe saying hey
        • scroll down   /   scroll up 3 times
        • type hello world
        • tap Search   /   go back   /   go home
        • take a photo   /   take a selfie
        • record a video for 20 seconds   /   stop recording
    """.trimIndent()

    fun run(ctx: Context, input: String, reply: (String) -> Unit) {
        val app = ctx.applicationContext
        scope.launch {
            val answer = try {
                execute(app, input)
            } catch (e: Exception) {
                "Sorry, that failed: ${e.message}"
            }
            reply(answer)
        }
    }

    // ------------------------------------------------------------------ parsing

    private suspend fun execute(ctx: Context, raw: String, useAi: Boolean = true): String {
        val text = raw.trim()
            .replace(Regex("^(hey |hi |ok |okay )?jarvis[,. ]*", RegexOption.IGNORE_CASE), "")
            .trim()
        val t = text.lowercase()
        if (t.isEmpty()) return "Yes? Tell me what to do."

        fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE).matchEntire(text)

        if (t == "help" || t == "what can you do") return HELP

        // ---- camera
        if (Regex("\\b(stop|end|finish)\\b.*\\b(recording|video)\\b").containsMatchIn(t)) {
            val cam = CameraActivity.current ?: return "I'm not recording right now."
            cam.stopRecording()
            return "Stopped recording."
        }
        if (Regex("\\b(record|shoot|capture|take)\\b.*\\bvideo\\b").containsMatchIn(t)) {
            val secs = Regex("for\\s+(\\d+)\\s*(second|sec|minute|min)").find(t)?.let {
                val n = it.groupValues[1].toInt()
                if (it.groupValues[2].startsWith("min")) n * 60 else n
            } ?: 30
            return openCamera(ctx, "video", "front" in t || "selfie" in t, secs)
        }
        if (Regex("\\b(take|click|capture|snap|shoot)\\b.*\\b(photo|picture|pic|selfie|image)\\b")
                .containsMatchIn(t)
        ) {
            return openCamera(ctx, "photo", "selfie" in t || "front" in t, 0)
        }
        if (t == "open camera" || t == "start camera") {
            ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).newTask())
            return "Opening the camera."
        }

        // ---- messaging
        rx(
            "(?:send\\s+)?(?:an?\\s+)?(whatsapp|whats app|sms|text|instagram|insta|ig)" +
                "(?:\\s+message|\\s+msg)?\\s+to\\s+(.+?)\\s+" +
                "(?:saying|say|that says|that|with message|message|:)\\s+(.+)"
        )?.let { return sendVia(ctx, it.groupValues[1], it.groupValues[2], it.groupValues[3]) }

        // "send hello to Rahul on whatsapp"
        rx(
            "(?:send|message|msg|text)\\s+(.+?)\\s+to\\s+(.+?)\\s+" +
                "(?:on|via|through|in|using)\\s+(whatsapp|whats app|instagram|insta|ig|sms)"
        )?.let { return sendVia(ctx, it.groupValues[3], it.groupValues[2], it.groupValues[1]) }

        // "send a message to Rahul on whatsapp saying hello" / "message Rahul on whatsapp hello"
        rx(
            "(?:send\\s+)?(?:an?\\s+)?(?:message|msg|text)\\s+(?:to\\s+)?(.+?)\\s+" +
                "(?:on|via|through|in|using)\\s+" +
                "(whatsapp|whats app|instagram|insta|ig|sms)\\s*(?:saying|say|that says|that|:)?\\s*(.+)"
        )?.let { return sendVia(ctx, it.groupValues[2], it.groupValues[1], it.groupValues[3]) }

        rx(
            "(?:send\\s+)?(?:an?\\s+)?(?:message|msg|text|sms)\\s+to\\s+(.+?)\\s+" +
                "(?:saying|say|that says|that|:)\\s+(.+)"
        )?.let { return sendVia(ctx, "sms", it.groupValues[1], it.groupValues[2]) }

        // ---- alarm / timer
        if (Regex("\\b(alarm|wake me)\\b").containsMatchIn(t) || "timer" in t) {
            val dur = Regex("(\\d+)\\s*(second|sec|minute|min|hour|hr)").find(t)
            if ("timer" in t || (dur != null && Regex("\\bin\\s+\\d+").containsMatchIn(t))) {
                if (dur == null) return "For how long? Say, for example: set timer for 10 minutes."
                val n = dur.groupValues[1].toInt()
                val unit = dur.groupValues[2]
                val seconds = when {
                    unit.startsWith("hour") || unit == "hr" -> n * 3600
                    unit.startsWith("min") -> n * 60
                    else -> n
                }
                return setTimer(ctx, seconds)
            }
            val seg = Regex("(?:alarm|wake me up|wake me)\\s*(.*)", RegexOption.IGNORE_CASE)
                .find(text)?.groupValues?.get(1) ?: text
            val time = parseTime(seg) ?: return "What time? Say, for example: set alarm at 6:30 am."
            return setAlarm(ctx, time.first, time.second)
        }

        // ---- call
        rx("(?:call|dial|phone|ring)\\s+(.+)")?.let { return call(ctx, it.groupValues[1]) }

        // ---- search
        rx("open\\s+(.+?)\\s+and\\s+search\\s+(?:for\\s+)?(.+)")?.let {
            return searchInApp(ctx, it.groupValues[2], it.groupValues[1])
        }
        rx("search\\s+(?:for\\s+)?(.+?)\\s+(?:on|in|at|inside)\\s+(.+)")?.let {
            return searchInApp(ctx, it.groupValues[1], it.groupValues[2])
        }
        rx("(?:google|search|look up)\\s+(?:for\\s+)?(.+)")?.let { return webSearch(ctx, it.groupValues[1]) }

        // ---- screen control
        rx("scroll(.*)")?.let {
            val rest = it.groupValues[1].lowercase()
            val dir = Regex("up|down|left|right").find(rest)?.value ?: "down"
            val times = Regex("(\\d+)").find(rest)?.groupValues?.get(1)?.toInt() ?: 1
            return scroll(dir, times.coerceIn(1, 20))
        }
        rx("(?:type|write|enter)\\s+(.+)")?.let {
            val svc = JarvisAccessibilityService.instance ?: return needControl()
            return if (svc.typeText(it.groupValues[1])) "Typed." else "I couldn't find a text field on screen."
        }
        rx("(?:tap|click|press|touch)\\s+(?:on\\s+)?(.+)")?.let {
            val svc = JarvisAccessibilityService.instance ?: return needControl()
            return if (svc.tap(it.groupValues[1])) "Tapped ${it.groupValues[1]}." else "I couldn't find \"${it.groupValues[1]}\" on screen."
        }
        if (t == "go back" || t == "back") {
            val svc = JarvisAccessibilityService.instance ?: return needControl()
            svc.goBack()
            return "Going back."
        }
        if (t == "go home" || t == "home" || t == "home screen") {
            val svc = JarvisAccessibilityService.instance ?: return needControl()
            svc.goHome()
            return "Going home."
        }

        // ---- open app
        rx("(?:open|launch|start)\\s+(.+)")?.let { return openApp(ctx, it.groupValues[1]) }

        val sorry = "Sorry, I didn't understand \"$text\". Say \"help\" to see what I can do."
        if (!useAi) return sorry
        if (!AiBrain.enabled(ctx)) {
            return "$sorry\n\nTip: tap the AI pill and add an API key so I can understand normal sentences."
        }
        val r = try {
            AiBrain.ask(ctx, text)
        } catch (e: Exception) {
            return "AI error: ${e.message}"
        }
        if (r.command.isNotBlank()) {
            val result = execute(ctx, r.command, useAi = false)
            return if (result.startsWith("Sorry, I didn't understand")) {
                r.reply.ifBlank { sorry }
            } else {
                result
            }
        }
        return r.reply.ifBlank { "I'm not sure how to help with that." }
    }

    private fun needControl() = "Please enable Jarvis control in Accessibility settings first."

    // ------------------------------------------------------------------ helpers

    private fun Intent.newTask(): Intent = apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    private fun granted(ctx: Context, perm: String) =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    private fun installed(ctx: Context, pkg: String) =
        ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    private fun launch(ctx: Context, pkg: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        ctx.startActivity(i.newTask())
    }

    private fun fmt(h: Int, m: Int): String {
        val suffix = if (h >= 12) "PM" else "AM"
        val hh = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(hh, m, suffix)
    }

    // ------------------------------------------------------------------ alarm / timer

    private fun parseTime(s: String): Pair<Int, Int>? {
        val m = Regex(
            "(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|a\\.m\\.|p\\.m\\.)?",
            RegexOption.IGNORE_CASE
        ).find(s) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3].lowercase().replace(".", "")
        if (ap == "pm" && h < 12) h += 12
        if (ap == "am" && h == 12) h = 0
        if (h > 23 || min > 59) return null
        return Pair(h, min)
    }

    private fun setAlarm(ctx: Context, h: Int, m: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .newTask()
        ctx.startActivity(i)
        return "Alarm set for ${fmt(h, m)}."
    }

    private fun setTimer(ctx: Context, seconds: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .newTask()
        ctx.startActivity(i)
        return "Timer started for ${if (seconds >= 60) "${seconds / 60} minutes" else "$seconds seconds"}."
    }

    // ------------------------------------------------------------------ contacts / calls / sms

    private fun findContactNumber(ctx: Context, name: String): String? {
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cursor.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    private fun resolveNumber(ctx: Context, who: String): String? {
        val w = who.trim().removePrefix("to ").trim()
        val digits = w.replace(Regex("[\\s()-]"), "")
        return if (Regex("^\\+?\\d{5,15}$").matches(digits)) digits else findContactNumber(ctx, w)
    }

    private fun toInternational(number: String): String {
        val d = number.replace(Regex("[\\s()-]"), "")
        return when {
            d.startsWith("+") -> d
            d.length == 10 -> "+$DEFAULT_COUNTRY_CODE$d"
            d.startsWith("0") -> "+$DEFAULT_COUNTRY_CODE${d.drop(1)}"
            else -> "+$d"
        }
    }

    private fun call(ctx: Context, who: String): String {
        val num = resolveNumber(ctx, who)
            ?: return "I couldn't find \"$who\" in your contacts. Say the number instead."
        val uri = Uri.fromParts("tel", num, null)
        return if (granted(ctx, Manifest.permission.CALL_PHONE)) {
            ctx.startActivity(Intent(Intent.ACTION_CALL, uri).newTask())
            "Calling $who."
        } else {
            ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).newTask())
            "I opened the dialer. Grant phone permission so I can dial directly."
        }
    }

    @Suppress("DEPRECATION")
    private fun sendSms(ctx: Context, number: String, body: String): String {
        if (!granted(ctx, Manifest.permission.SEND_SMS)) {
            ctx.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
                    .putExtra("sms_body", body)
                    .newTask()
            )
            return "I don't have SMS permission, so I opened the message for you to send."
        }
        val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(body), null, null)
        return "SMS sent to $number."
    }

    private suspend fun sendVia(ctx: Context, channel: String, who: String, body: String): String {
        val ch = channel.lowercase()
        return when {
            ch.startsWith("whats") -> whatsapp(ctx, who, body)
            ch == "instagram" || ch == "insta" || ch == "ig" -> instagram(ctx, who, body)
            else -> {
                val num = resolveNumber(ctx, who)
                    ?: return "I couldn't find \"$who\" in your contacts. Say the number instead."
                sendSms(ctx, num, body)
            }
        }
    }

    private suspend fun whatsapp(ctx: Context, who: String, body: String): String {
        val num = resolveNumber(ctx, who)
            ?: return "I couldn't find \"$who\" in your contacts. Say the number instead."
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(ctx, it) }
            ?: return "WhatsApp isn't installed."
        val intl = toInternational(num).removePrefix("+")
        val uri = Uri.parse("https://wa.me/$intl?text=${Uri.encode(body)}")
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).newTask())

        val svc = JarvisAccessibilityService.instance
            ?: return "WhatsApp is open with your message typed. Enable Jarvis control so I can press Send."
        delay(3500)
        repeat(4) {
            if (svc.tap("send")) return "Sent your WhatsApp message to $who."
            delay(1000)
        }
        return "I opened the chat but couldn't find the Send button. Tap Send yourself."
    }

    private suspend fun instagram(ctx: Context, userRaw: String, body: String): String {
        val user = userRaw.trim().removePrefix("@").replace(" ", "")
        if (!installed(ctx, "com.instagram.android")) return "Instagram isn't installed."
        val svc = JarvisAccessibilityService.instance
            ?: return "Enable Jarvis control first so I can drive Instagram."
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/$user"))
                .setPackage("com.instagram.android")
                .newTask()
        )
        delay(4000)
        if (!svc.tap("message")) return "I opened @$user's profile but couldn't find the Message button."
        delay(3000)
        if (!svc.typeText(body)) return "I opened the chat but couldn't type into it."
        delay(800)
        return if (svc.tap("send")) "Sent your Instagram message to @$user." else "Typed your message. Tap Send to finish."
    }

    // ------------------------------------------------------------------ apps / search

    private fun findApp(ctx: Context, name: String): String? {
        val q = name.lowercase().trim()
        val aliases = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "instagram" to "com.instagram.android",
            "chrome" to "com.android.chrome",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "gmail" to "com.google.android.gm",
            "spotify" to "com.spotify.music",
            "facebook" to "com.facebook.katana",
            "telegram" to "org.telegram.messenger",
            "snapchat" to "com.snapchat.android",
            "play store" to "com.android.vending"
        )
        aliases[q]?.let { if (installed(ctx, it)) return it }
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val labeled = pm.queryIntentActivities(main, 0)
            .map { Pair(it.loadLabel(pm).toString().lowercase(), it.activityInfo.packageName) }
        return labeled.firstOrNull { it.first == q }?.second
            ?: labeled.firstOrNull { it.first.contains(q) }?.second
    }

    private fun openApp(ctx: Context, name: String): String {
        val pkg = findApp(ctx, name) ?: return "I couldn't find an app called \"$name\"."
        launch(ctx, pkg)
        return "Opening $name."
    }

    private fun webSearch(ctx: Context, query: String): String {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query).newTask()
        return try {
            ctx.startActivity(i)
            "Searching for $query."
        } catch (e: Exception) {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).newTask()
            )
            "Searching for $query."
        }
    }

    private suspend fun searchInApp(ctx: Context, query: String, appName: String): String {
        val app = appName.lowercase().trim()
        val enc = Uri.encode(query)

        // Apps with a reliable search link: no screen control needed.
        val deep: Pair<String, String>? = when {
            "youtube" in app -> Pair("https://www.youtube.com/results?search_query=$enc", "com.google.android.youtube")
            "map" in app -> Pair("geo:0,0?q=$enc", "com.google.android.apps.maps")
            "play store" in app || "playstore" in app -> Pair("market://search?q=$enc", "com.android.vending")
            "spotify" in app -> Pair("spotify:search:$enc", "com.spotify.music")
            else -> null
        }
        if (deep != null) {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(deep.first)).newTask()
            if (installed(ctx, deep.second)) i.setPackage(deep.second)
            return try {
                ctx.startActivity(i)
                "Searching $query on $appName."
            } catch (e: Exception) {
                "I couldn't open $appName for that search."
            }
        }
        if (app == "google" || app == "chrome" || app == "browser" || app == "web") {
            return webSearch(ctx, query)
        }

        // Any other app: open it, then use the screen-control service to search.
        val pkg = findApp(ctx, app) ?: return webSearch(ctx, "$query $appName")
        launch(ctx, pkg)
        val svc = JarvisAccessibilityService.instance
            ?: return "Opened $appName. Enable Jarvis control so I can type the search for you."
        delay(3000)
        svc.tap("search")
        delay(1200)
        if (!svc.typeText(query)) return "Opened $appName but couldn't find its search box."
        delay(600)
        if (!svc.submit()) svc.tap("search")
        return "Searching $query in $appName."
    }

    // ------------------------------------------------------------------ screen control / camera

    private suspend fun scroll(direction: String, times: Int): String {
        val svc = JarvisAccessibilityService.instance ?: return needControl()
        var ok = false
        repeat(times) {
            ok = svc.scroll(direction)
            delay(500)
        }
        return if (ok) "Scrolled $direction." else "Scrolling didn't work on this screen."
    }

    private fun openCamera(ctx: Context, mode: String, front: Boolean, seconds: Int): String {
        if (!granted(ctx, Manifest.permission.CAMERA)) {
            return "I need camera permission. Tap \"Grant permissions\" first."
        }
        val i = Intent(ctx, CameraActivity::class.java)
            .putExtra("mode", mode)
            .putExtra("front", front)
            .putExtra("seconds", if (seconds > 0) seconds else 30)
            .newTask()
        ctx.startActivity(i)
        return if (mode == "video") "Recording a video." else "Taking a photo."
    }
}
