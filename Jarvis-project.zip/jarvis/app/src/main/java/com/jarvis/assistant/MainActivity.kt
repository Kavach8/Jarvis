package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null

    private val neededPermissions: Array<String> by lazy {
        val list = mutableListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT <= 28) list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        list.toTypedArray()
    }

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !spoken.isNullOrBlank()) handle(spoken)
    }

    private val permissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        log = findViewById(R.id.logText)
        logScroll = findViewById(R.id.logScroll)
        input = findViewById(R.id.commandInput)
        status = findViewById(R.id.statusText)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.sendButton).setOnClickListener { sendTyped() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendTyped()
                true
            } else {
                false
            }
        }
        findViewById<Button>(R.id.micButton).setOnClickListener {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening...")
            try {
                speech.launch(i)
            } catch (e: Exception) {
                append("Jarvis: Speech recognition isn't available on this device. Type your command instead.")
            }
        }
        findViewById<Button>(R.id.permButton).setOnClickListener {
            permissionRequest.launch(neededPermissions)
        }
        findViewById<Button>(R.id.accessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        append("Jarvis: Online. Say \"help\" to see what I can do.")
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun sendTyped() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        handle(text)
    }

    private fun handle(command: String) {
        append("You: $command")
        JarvisEngine.run(applicationContext, command) { answer ->
            append("Jarvis: $answer")
            tts?.speak(answer.lines().first(), TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun append(line: String) {
        log.append(line + "\n\n")
        logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun updateStatus() {
        val granted = neededPermissions.count {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        val control = if (JarvisAccessibilityService.instance != null) "ON" else "OFF"
        status.text = "Screen control: $control  |  Permissions: $granted/${neededPermissions.size}"
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
