package com.jarvis.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var chatList: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var accessPill: TextView
    private lateinit var permPill: TextView
    private lateinit var subtitle: TextView
    private lateinit var orb: View
    private var orbAnimator: ObjectAnimator? = null
    private var tts: TextToSpeech? = null

    private val neededPermissions: Array<String> by lazy {
        val list = mutableListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT <= 28) list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        list.toTypedArray()
    }

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !spoken.isNullOrBlank()) handle(spoken)
    }

    private val permissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updateStatus() }

    // label shown on the chip, text to use, true = run immediately, false = fill the input for editing
    private val chips = listOf(
        Triple("⏰  Alarm", "set alarm at ", false),
        Triple("📞  Call", "call ", false),
        Triple("💬  WhatsApp", "whatsapp to  saying ", false),
        Triple("✉️  SMS", "send sms to  saying ", false),
        Triple("📸  Photo", "take a photo", true),
        Triple("🎥  Video", "record a video", true),
        Triple("▶️  YouTube", "open YouTube", true),
        Triple("🔎  Search", "search ", false),
        Triple("⬇️  Scroll", "scroll down", true),
        Triple("❓  Help", "help", true)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chatList = findViewById(R.id.chatList)
        logScroll = findViewById(R.id.logScroll)
        input = findViewById(R.id.commandInput)
        accessPill = findViewById(R.id.accessPill)
        permPill = findViewById(R.id.permPill)
        subtitle = findViewById(R.id.subtitle)
        orb = findViewById(R.id.orb)
        tts = TextToSpeech(this, this)

        startOrbPulse(1600L)
        buildChips()

        findViewById<View>(R.id.sendButton).setOnClickListener { sendTyped() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendTyped()
                true
            } else {
                false
            }
        }
        findViewById<View>(R.id.micButton).setOnClickListener {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening...")
            try {
                speech.launch(i)
            } catch (e: Exception) {
                addBubble("Speech recognition isn't available on this device. Type your command instead.", false)
            }
        }
        permPill.setOnClickListener { permissionRequest.launch(neededPermissions) }
        accessPill.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        addBubble(
            "Hello, I'm Jarvis. Tap a shortcut above, type a command, or press the mic.\n\n" +
                "Tip: tap the status pills at the top to grant permissions and enable screen control.",
            false
        )
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    // ------------------------------------------------------------------ UI helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun startOrbPulse(durationMs: Long) {
        orbAnimator?.cancel()
        val a = ObjectAnimator.ofPropertyValuesHolder(
            orb,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.14f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0.75f)
        )
        a.duration = durationMs
        a.repeatCount = ObjectAnimator.INFINITE
        a.repeatMode = ObjectAnimator.REVERSE
        a.interpolator = AccelerateDecelerateInterpolator()
        a.start()
        orbAnimator = a
    }

    private fun buildChips() {
        val row = findViewById<LinearLayout>(R.id.chipRow)
        for ((label, cmd, runNow) in chips) {
            val chip = TextView(this).apply {
                this.text = label
                setTextColor(Color.parseColor("#CFE9FF"))
                textSize = 13f
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setBackgroundResource(R.drawable.bg_chip)
                setOnClickListener {
                    if (runNow) {
                        handle(cmd)
                    } else {
                        input.setText(cmd)
                        input.setSelection(input.text.length)
                        input.requestFocus()
                        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = dp(8)
            row.addView(chip, lp)
        }
    }

    private fun addBubble(text: String, fromUser: Boolean) {
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(if (fromUser) Color.WHITE else Color.parseColor("#E3F2FD"))
            setLineSpacing(0f, 1.1f)
            setPadding(dp(16), dp(11), dp(16), dp(11))
            setBackgroundResource(if (fromUser) R.drawable.bg_bubble_user else R.drawable.bg_bubble_jarvis)
            maxWidth = (resources.displayMetrics.widthPixels * 0.80f).toInt()
            setTextIsSelectable(true)
            alpha = 0f
            translationY = dp(12).toFloat()
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = if (fromUser) Gravity.END else Gravity.START
        lp.topMargin = dp(5)
        lp.bottomMargin = dp(5)
        chatList.addView(bubble, lp)
        bubble.animate().alpha(1f).translationY(0f).setDuration(220).start()
        logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun updateStatus() {
        val granted = neededPermissions.count {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        val total = neededPermissions.size
        val green = Color.parseColor("#00E676")
        val amber = Color.parseColor("#FFB300")

        val controlOn = JarvisAccessibilityService.instance != null
        accessPill.text = if (controlOn) "●  Screen control ON" else "○  Enable screen control"
        accessPill.setTextColor(if (controlOn) green else amber)

        permPill.text = if (granted == total) "●  Permissions $granted/$total" else "○  Grant permissions $granted/$total"
        permPill.setTextColor(if (granted == total) green else amber)
    }

    // ------------------------------------------------------------------ commands

    private fun sendTyped() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        handle(text)
    }

    private fun handle(command: String) {
        addBubble(command, true)
        subtitle.text = "Working on it…"
        startOrbPulse(500L)
        JarvisEngine.run(applicationContext, command) { answer ->
            addBubble(answer, false)
            subtitle.text = "Online · ready for your command"
            startOrbPulse(1600L)
            tts?.speak(answer.lines().first(), TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    override fun onDestroy() {
        orbAnimator?.cancel()
        tts?.shutdown()
        super.onDestroy()
    }
}
