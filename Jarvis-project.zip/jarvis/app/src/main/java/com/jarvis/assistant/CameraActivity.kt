package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Takes one photo automatically, or records a video until stopped
 * (Stop button, the voice command "stop recording", or the time limit).
 * Extras: mode = "photo" | "video", front = Boolean, seconds = Int (video limit).
 */
class CameraActivity : AppCompatActivity() {

    companion object {
        @Volatile
        var current: CameraActivity? = null
    }

    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private val handler = Handler(Looper.getMainLooper())
    private var mode = "photo"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)
        current = this
        previewView = findViewById(R.id.previewView)
        status = findViewById(R.id.camStatus)
        mode = intent.getStringExtra("mode") ?: "photo"
        val front = intent.getBooleanExtra("front", false)
        val seconds = intent.getIntExtra("seconds", 30)
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            if (mode == "video") stopRecording() else finish()
        }
        startCamera(front, seconds)
    }

    private fun startCamera(front: Boolean, seconds: Int) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val selector = if (front) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }
                provider.unbindAll()
                if (mode == "video") {
                    val recorder = Recorder.Builder()
                        .setQualitySelector(
                            QualitySelector.from(
                                Quality.HD,
                                FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                            )
                        )
                        .build()
                    val vc = VideoCapture.withOutput(recorder)
                    videoCapture = vc
                    provider.bindToLifecycle(this, selector, preview, vc)
                    handler.postDelayed({ beginRecording(seconds) }, 800)
                } else {
                    val ic = ImageCapture.Builder().build()
                    imageCapture = ic
                    provider.bindToLifecycle(this, selector, preview, ic)
                    handler.postDelayed({ takePhoto() }, 1500)
                }
            } catch (e: Exception) {
                status.text = "Camera error: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stamp(): String =
        "JARVIS_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, stamp())
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Jarvis")
            }
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()
        ic.takePicture(
            options,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    status.text = "Photo saved to Pictures/Jarvis"
                    handler.postDelayed({ finish() }, 1200)
                }

                override fun onError(exception: ImageCaptureException) {
                    status.text = "Photo failed: ${exception.message}"
                }
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun beginRecording(seconds: Int) {
        val vc = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, stamp())
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Jarvis")
            }
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = vc.output.prepareRecording(this, options)
        val audioOk = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (audioOk) pending = pending.withAudioEnabled()

        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> status.text = "Recording... (say \"stop recording\")"
                is VideoRecordEvent.Finalize -> {
                    status.text = if (event.hasError()) {
                        "Video error ${event.error}"
                    } else {
                        "Video saved to Movies/Jarvis"
                    }
                    handler.postDelayed({ finish() }, 1200)
                }
                else -> {}
            }
        }
        handler.postDelayed({ stopRecording() }, seconds * 1000L)
    }

    fun stopRecording() {
        recording?.stop()
        recording = null
    }

    override fun onDestroy() {
        if (current === this) current = null
        handler.removeCallbacksAndMessages(null)
        recording?.stop()
        recording = null
        super.onDestroy()
    }
}
